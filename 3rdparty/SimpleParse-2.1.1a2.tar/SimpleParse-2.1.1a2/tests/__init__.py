"""Package of test scripts, is a package to make setup.py include it :)

Run test.py from the command line to run all the primary tests,
it will take a while (10 seconds or so) even on a properly
configured system.  A system with an old copy of mx.TextTools
might actually experience an infinite loop or a C stack recursion
error.
"""
